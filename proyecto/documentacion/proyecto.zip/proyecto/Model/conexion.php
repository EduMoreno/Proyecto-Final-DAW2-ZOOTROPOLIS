﻿<?php
abstract class Zoo {

  public static function conectar() {
    try {
      $conectar = new PDO("mysql:host=mysql.hostinger.es;dbname=u166917992_zoo;charset=utf8", 'u166917992_root', 'usuario'); 
    } catch (PDOException $e) {
      echo "No se ha podido establecer conexión con el servidor de bases de datos.<br>";
      die ("Error: " . $e->getMessage());
    }

    return $conectar;
  }
}