<?php
$host="mysql.hostinger.es";
$user="u166917992_root";
$password="usuario";
$db="u166917992_zoo";
$con = new mysqli($host,$user,$password,$db);

?>