<html>
	<head>
    <title>Zootropolis</title>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="favicon.ico">  
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <!-- CSS Global  -->
	<link rel="stylesheet" href="../View/CSS/Administrador/acceso.css">
    <!-- CSS Plugins -->
    <link rel="stylesheet" href="assets/plugins/font-awesome/css/font-awesome.css">
	
	    <link rel="stylesheet" href="aplicacion/css/bootstrap.css">   

 
    
</head> 
	<body style="background:url(aplicacion/images/log.jpg) no-repeat;background-size: cover;  height:100%; width:100%;">
 <div id="form-div">
 <div class="submit">

<a href="login_trabajo.php"><button type="button" class="btn btn-primary btn-lg btn-block">Acceso Cuidadores</button></a>
<a href="login.php"><button type="button" class="btn btn-default btn-lg btn-block">Acceso Usuarios</button></a>
                      
                    </div>
 </div>
	</body>
</html>